﻿namespace PhoneBook
{
}

namespace PhoneBook
{


    public partial class PhoneData
    {
    }
}
